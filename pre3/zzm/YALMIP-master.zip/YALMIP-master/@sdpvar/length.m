function n=length(X)
%LENGTH (overloaded)

n = max(X.dim);
